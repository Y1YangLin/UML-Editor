module uml_editor {
	requires java.desktop;
	
	
}