package Mode;

import java.awt.Point;

import Shape.AssoLine;
import Shape.CompLine;
import Shape.GeneLine;
import Shape.Line;
import Shape.Obj;
import Shape.Obj_class;
import Shape.Obj_usecase;

public class ShapeCreator implements ShapeCreatorInterface{

	@Override
	public Obj createObj(String objname, Point point) {
		// TODO Auto-generated method stub
		
		switch(objname) {
			case "class":
				return new Obj_class(point.x,point.y);
				
			case "usecase":
				
				return new Obj_usecase(point.x,point.y);
		}
		
		return null;
	}

	
	@Override
	public Line createLine(String linename, Point prev,Point next) {
		// TODO Auto-generated method stub
		
		switch(linename) {
			case "association":
				return new AssoLine(prev.x,prev.y,next.x,next.y);
			case "generalization":
				return new GeneLine(prev.x,prev.y,next.x,next.y);
			case "composition":
				return new CompLine(prev.x,prev.y,next.x,next.y);
		}
		
		
		return null;
	}

}
