package Mode;

import java.awt.event.MouseEvent;

import Shape.Obj;

public class CreateObjMode extends Mode{
	private String objname;
	private ShapeCreatorInterface creator = new ShapeCreator();
	
	public CreateObjMode(String name) {
		objname = name;
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		Obj obj = creator.createObj(objname,e.getPoint());
		
//		System.out.println("666");
		canvas.addshape(obj);
		canvas.repaint();
		
	}
}
