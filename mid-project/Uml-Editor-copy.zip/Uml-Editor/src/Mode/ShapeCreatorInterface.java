package Mode;

import java.awt.Point;

import Shape.Line;
import Shape.Obj;

public interface ShapeCreatorInterface {

	Obj createObj(String objname, Point point);
	Line createLine(String linename, Point prev,Point next);
}
